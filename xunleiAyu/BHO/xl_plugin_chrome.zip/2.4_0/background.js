// listen content_script

var bPluginEnabled = true;
var blackListWebsites;
var blackListPages;

function GetBlackListWebsites()
{
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	blackListWebsites = xl_plugin.GetBlackListWebsites();
	if (!blackListWebsites)
	{
		blackListWebsites = new Array();
	}
}

function GetBlackListPages()
{
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	blackListPages = xl_plugin.GetBlackListPages();
	if (!blackListPages)
	{
		blackListPages = new Array();
	}
}

function SetPluginEnabled(bEnabled)
{
	chrome.tabs.getSelected(null,
		function(tab)
		{
			chrome.tabs.sendMessage(tab.id, {name:"UpdatePluginEnabled", enable:bEnabled});
		}
	);
	
	bPluginEnabled = bEnabled;
	
	var iconPath = bPluginEnabled ? "images/icon19_normal.png" : "images/icon19_disabled.png";
	UpdateBrowserActionIcon(iconPath);
	
	UpdateContextMenu(bEnabled);
	
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	xl_plugin.SetPluginEnabled(bEnabled);
}

function InitPluginEnabled()
{
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	bPluginEnabled = xl_plugin.GetPluginEnabled();
}

function OnFeedback()
{
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	bPluginEnabled = xl_plugin.Feedback();
}

function AddBlackListPage(url)
{
	for (var i in blackListPages)
	{
		if (blackListPages[i] == url)
		{
			// 去重
			return;
		}
	}
	
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	var ret = xl_plugin.AddBlackListPage(url);
	if (ret)
	{
		chrome.tabs.getSelected(null,
			function(tab)
			{
				chrome.tabs.sendMessage(tab.id, {name:"UpdatePageEnabled", enable:false});
			}
		);
		
		blackListPages[blackListPages.length] = url;
	}
}

function RemoveBlackListPage(url)
{
	for (var i in blackListPages)
	{
		if (blackListPages[i] == url)
		{
			var xl_plugin = document.getElementById('xl_chrome_plugin');
			var ret = xl_plugin.RemoveBlackListPage(url);
			if (ret)
			{
				chrome.tabs.getSelected(null,
					function(tab)
					{
						chrome.tabs.sendMessage(tab.id, {name:"UpdatePageEnabled", enable:true});
					}
				);
				delete blackListPages[i];
			}
			return;
		}
	}
}

function AddBlackListWebsite(url)
{
	for (var i in blackListWebsites)
	{
		if (blackListWebsites[i] == url)
		{
			// 去重
			return;
		}
	}
	
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	var ret = xl_plugin.AddBlackListWebsite(url);
	if (ret)
	{
		chrome.tabs.getSelected(null,
			function(tab)
			{
				chrome.tabs.sendMessage(tab.id, {name:"UpdateWebsiteEnabled", enable:false});
			}
		);
		
		blackListWebsites[blackListWebsites.length] = url;
	}
}

function RemoveBlackListWebsite(url)
{
	for (var i in blackListWebsites)
	{
		if (blackListWebsites[i] == url)
		{
			var xl_plugin = document.getElementById('xl_chrome_plugin');
			var ret = xl_plugin.RemoveBlackListWebsite(url);
			if (ret)
			{
				chrome.tabs.getSelected(null,
					function(tab)
					{
						chrome.tabs.sendMessage(tab.id, {name:"UpdateWebsiteEnabled", enable:true});
					}
				);
				
				delete blackListWebsites[i];
			}
			return;
		}
	}
}

function CheckIsWebsiteInUserBlackList(url)
{
	for (var i in blackListWebsites)
	{
		if (url.indexOf(blackListWebsites[i]) == 0)
		{
			// 匹配
			return true;
		}
	}
	
	return false;
}

function CheckIsPageInUserBlackList(url)
{
	for (var i in blackListPages)
	{
		if (url == blackListPages[i])
		{
			// 匹配
			return true;
		}
	}
	
	return false;
}

// menu click
function onStartupThunder(info, tab) {
	chrome.cookies.getAll({url:info.pageUrl}, function(cookies) {
		var cookie = "";
		for (i in cookies) {
			cookie = cookie.concat(cookies[i].name, "=", cookies[i].value, "; ");
		};
		InvokeThunder(info.linkUrl, cookie, info.pageUrl);
	});
}

// invoke thunder
function InvokeThunder(link, cookie, referurl) {
	if (!bPluginEnabled)
	{
		return;
	}
	
	var g_strSplitter = "#@$@#";
	var strUrls = referurl;
	strUrls = strUrls.concat(g_strSplitter);
	strUrls = strUrls.concat(1, g_strSplitter);
	
	strUrls = strUrls.concat(link, g_strSplitter);
	strUrls = strUrls.concat("", g_strSplitter);
	strUrls = strUrls.concat("", g_strSplitter);
	strUrls = strUrls.concat(cookie, g_strSplitter);
	strUrls = strUrls.concat("", g_strSplitter);
	strUrls = strUrls.concat("", g_strSplitter);
	var xl_plugin = document.getElementById('xl_chrome_plugin');
	
	return xl_plugin.DownLoadByThunder(strUrls);
}

// 创建右键菜单
function CreateContextMenu(bEnableMenu)
{
	chrome.contextMenus.create({id:"ThunderContextMenu", type:"normal", title:chrome.i18n.getMessage("context_title"), contexts:["link"], onclick:onStartupThunder, enabled:bEnableMenu});
}

// 更新右键菜单
function UpdateContextMenu(bEnableMenu)
{
	chrome.contextMenus.update("ThunderContextMenu", {enabled:bEnableMenu});
}

// 更新工具栏图标
function UpdateBrowserActionIcon(iconPath)
{
	chrome.browserAction.setIcon({path:iconPath});
}

function RegisterEventListener()
{
	chrome.tabs.onActivated.addListener(
		function (activeInfo)
		{
			chrome.tabs.sendMessage(activeInfo.tabId, {name:"OnActivated"});
		}
	);
	
	chrome.extension.onRequest.addListener(
		function (request, sender, response)
		{
			if (request.name == "xl_download")
			{
				InvokeThunder(request.link, request.cookie, request.referurl);
			}
			else if (request.name == "CheckEnabled")
			{
				var bPlugin  = bPluginEnabled;
				var bWebsite = !CheckIsWebsiteInUserBlackList(request.url);
				var bPage = !CheckIsPageInUserBlackList(request.url);
				
				response({bPlugin:bPlugin, bWebsite:bWebsite, bPage:bPage});
			}
		}
	);

}

function Init()
{
	InitPluginEnabled();
	GetBlackListWebsites();
	GetBlackListPages();
	
	CreateContextMenu(bPluginEnabled);
	
	var iconPath = bPluginEnabled ? "images/icon19_normal.png" : "images/icon19_disabled.png";
	UpdateBrowserActionIcon(iconPath);
	
	RegisterEventListener();
}

Init();