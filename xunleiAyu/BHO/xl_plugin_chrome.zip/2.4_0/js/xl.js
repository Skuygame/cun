﻿/*
	thunder network
*/

var bLoaded;

var bPluginEnabled;
var bWebsiteEnabled;
var bPageEnabled;

var whiteRegexpArray = [".+sina.com.*\\/d_load.php\\?.+",
						".+pcpop.com.*\\/redose.aspx\\?.+",
						".+pcpop.com.*\\/download.php\\?.+",
						".+pconline.com.cn\\/filedown.jsp\\?.+",
						".+chinaz.com\\/download.asp\\?.+",
						".+cnzz.cn\\/download.aspx\\?.+",
						".+zol.com.*\\/down.php\\?.+",
						".+zol.com.*\\?.*url=([^\\&]+).*",
						".+crsky.com.*\\?down_url=([^\\&]+).*",
						".+skycn.com.*\\/down.php\\?uri=(.+)",
						".+downxia.com.*\\/download.asp\\?.*url=(.+)"
						];
							
var blackRegexpArray = ["http.+\\?.*url=.+",
						"http.+\\?.*uri=.+"
						];

function checkWhiteDynamicLink(linkUrl) {
	for( var i in whiteRegexpArray ) {
		var regexp = new RegExp(whiteRegexpArray[i], "i");
		var result = regexp.exec(linkUrl);
		
		if (result == linkUrl) {
			return result;
		}
		
		if (result != null && result.length == 2) {
			return result[1];
		}
	}
	
	return null;
}

function checkBlackDynamicLink(linkUrl) {
	for( var i in blackRegexpArray ) {
		var regexp = new RegExp(blackRegexpArray[i], "i");
		var result = regexp.exec(linkUrl);
		
		if (result != null) {
			return result;
		}
	}
	
	return null;
}

function checkDownloadLink(linkUrl) {
	var npChromeMimeType = navigator.mimeTypes["application/xl_chrome_plugin"];
	if (npChromeMimeType) {
		var npChromePlugin = document.createElement("embed");
		npChromePlugin.style.visibility = "hidden";
		npChromePlugin.type = "application/xl_chrome_plugin";
		npChromePlugin.width = 0;
		npChromePlugin.height = 0;
		document.body.appendChild(npChromePlugin);
		
		var bIsDownloadURL = npChromePlugin.IsDownloadURL(linkUrl, document.cookie, document.location.href);
		/*if (bIsDownloadURL == false) {
			bIsDownloadURL = npChromePlugin.IsDynamicURL(linkUrl, document.cookie, document.location.href);
		}
		*/
		document.body.removeChild(npChromePlugin);
		
		return bIsDownloadURL;
	}
	
	return false;
}

function CheckEnabled(url)
{
	chrome.extension.sendRequest(
		{name:'CheckEnabled', url:url},
		function (response)
		{
			bPluginEnabled = response.bPlugin;
			bWebsiteEnabled = response.bWebsite;
			bPageEnabled = response.bPage;
		}
	);
}

// link click event
function onLinkClick(event) {
	if (bPluginEnabled && bWebsiteEnabled && bPageEnabled)
	{
		var linkUrl = this.href;
		
		var checkResult = checkWhiteDynamicLink(linkUrl);
		if (checkResult != null) {
			chrome.extension.sendRequest({name:"xl_download", link:checkResult, cookie:document.cookie, referurl:document.location.href});
			return event.preventDefault();
		}
		
		checkResult = checkBlackDynamicLink(linkUrl);
		if (checkResult != null) {
			return;
		}
		
		checkResult = checkDownloadLink(linkUrl);
		if (checkResult != false) {
			chrome.extension.sendRequest({name:"xl_download", link:linkUrl, cookie:document.cookie, referurl:document.location.href});
			return event.preventDefault();
		}
	}
}



function RegisterEventListener()
{
	// attach link click event
	for( var i = 0; i < document.links.length; i++ ) {
		var link = document.links[i];
		link.addEventListener("click", onLinkClick, false);
	}
	
	chrome.extension.onMessage.addListener(
		function(message, sender, sendResponseCallback)
		{
			if (message.name == "UpdatePluginEnabled")
			{
				bPluginEnabled = message.enable;
			}
			else if (message.name == "UpdateWebsiteEnabled")
			{
				bWebsiteEnabled = message.enable;
			}
			else if (message.name == "UpdatePageEnabled")
			{
				bPageEnabled = message.enable;
			}
			else if (message.name == "OnActivated")
			{
				if (bLoaded)
				{
					// 切换回当前页，重新查询enable状态
					CheckEnabled(document.location.href);
				}
			}
		}
	);
}

function Init()
{
	bLoaded = true;
	
	// 初始化时主动请求一次enable查询
	CheckEnabled(document.location.href);
	
	RegisterEventListener();
}

Init();