// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

var extension;
var bPluginEnabled;
var bIsInWebsiteBlackList;
var bIsInPageBlackList;

function OnClickThunderChromeSupport(e)
{
	extension.SetPluginEnabled(!bPluginEnabled);
	window.close();
}

function OnClickThisPageDisableThunder(e)
{
	if (bPluginEnabled)
	{
		chrome.tabs.getSelected(null,
			function(tab)
			{
				if (bIsInPageBlackList)
				{
					// 从网页黑名单里移除
					extension.RemoveBlackListPage(tab.url);
				}
				
				if (bIsInWebsiteBlackList)
				{
					// 从网站黑名单里移除
					var tmpUrl = tab.url;
					var idx1 = tmpUrl.indexOf("http://");
					var idx2 = tmpUrl.indexOf("/", idx1+7);
					var url = tmpUrl.substring(0, idx2);
					extension.RemoveBlackListWebsite(url);
				}
				else
				{
					if (!bIsInPageBlackList)
					{
						// 添加进网页黑名单
						extension.AddBlackListPage(tab.url);
					}
				}
			}
		);
		
		window.close();
	}
}

function OnClickThisWebsiteDisableThunder(e)
{
	if (bPluginEnabled)
	{
		chrome.tabs.getSelected(null,
			function(tab)
			{
				var tmpUrl = tab.url;
				var idx1 = tmpUrl.indexOf("http://");
				var idx2 = tmpUrl.indexOf("/", idx1+7);
				var url = tmpUrl.substring(0, idx2);
				
				if (bIsInWebsiteBlackList)
				{
					// 从网站黑名单里移除
					extension.RemoveBlackListWebsite(url)
				}
				else
				{
					// 添加进网站黑名单
					extension.AddBlackListWebsite(url);
				}
			}
		);
		
		window.close();
	}
}

function OnClickFeedback(e)
{
	extension.OnFeedback();
}

function Init()
{
	extension = chrome.extension.getBackgroundPage();
	bPluginEnabled = extension.bPluginEnabled;
	
	if (bPluginEnabled)
	{
		document.getElementById('ThunderChromeSupport').className= 'item item-select';
		
		chrome.tabs.getSelected(null,
			function(tab)
			{
				bIsInWebsiteBlackList = extension.CheckIsWebsiteInUserBlackList(tab.url);
				bIsInPageBlackList = extension.CheckIsPageInUserBlackList(tab.url);
				if (bIsInWebsiteBlackList)
				{
					document.getElementById('ThisPageDisableThunder').className= 'item item-select';
					document.getElementById('ThisWebsiteDisableThunder').className= 'item item-select';
				}
				else
				{
					if (bIsInPageBlackList)
					{
						document.getElementById('ThisPageDisableThunder').className= 'item item-select';
					}
				}
			}
		);
	}
	else
	{
		document.getElementById('ThunderChromeSupport').className= 'item';
		document.getElementById('ThisPageDisableThunder').className= 'item-disable';
		document.getElementById('ThisWebsiteDisableThunder').className= 'item-disable';
	}
}

document.addEventListener('DOMContentLoaded',
	function ()
	{
		var divs = document.querySelectorAll('div');
		divs["ThunderChromeSupport"].addEventListener('click', OnClickThunderChromeSupport);
		divs["ThisPageDisableThunder"].addEventListener('click', OnClickThisPageDisableThunder);
		divs["ThisWebsiteDisableThunder"].addEventListener('click', OnClickThisWebsiteDisableThunder);
		divs["Feedback"].addEventListener('click', OnClickFeedback);

		Init();
	}
);
